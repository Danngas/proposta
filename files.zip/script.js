// =====================================================
// ENNER ENGENHARIA — PROPOSTA COMERCIAL
// Lógica da capa: dados dinâmicos + cálculo automático de datas
// =====================================================

const MESES = [
  "janeiro","fevereiro","março","abril","maio","junho",
  "julho","agosto","setembro","outubro","novembro","dezembro"
];

function formatarDataBR(date){
  const dd = String(date.getDate()).padStart(2,'0');
  const mm = String(date.getMonth()+1).padStart(2,'0');
  const yyyy = date.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}

function somarDias(date, dias){
  const d = new Date(date);
  d.setDate(d.getDate() + dias);
  return d;
}

// Preenche automaticamente a data de hoje no input, ao carregar
function inicializarData(){
  const inputData = document.getElementById('in-data');
  const hoje = new Date();
  const iso = hoje.toISOString().split('T')[0];
  inputData.value = iso;
}

function atualizarCapa(){
  const cliente = document.getElementById('in-cliente').value.trim() || '—';
  const representante = document.getElementById('in-representante').value.trim() || '—';
  const cidade = document.getElementById('in-cidade').value.trim() || '—';
  const dataStr = document.getElementById('in-data').value;
  const diasValidade = parseInt(document.getElementById('in-validade-dias').value, 10) || 5;

  // data da proposta (evita problema de fuso usando componentes locais)
  let dataProposta;
  if(dataStr){
    const [y,m,d] = dataStr.split('-').map(Number);
    dataProposta = new Date(y, m-1, d);
  } else {
    dataProposta = new Date();
  }

  const dataValidade = somarDias(dataProposta, diasValidade);

  document.getElementById('out-cliente').textContent = cliente;
  document.getElementById('out-representante').textContent = representante;
  document.getElementById('out-cidade').textContent = cidade;
  document.getElementById('out-data').textContent = formatarDataBR(dataProposta);
  document.getElementById('out-validade').textContent = formatarDataBR(dataValidade);
}

document.addEventListener('DOMContentLoaded', () => {
  inicializarData();
  atualizarCapa(); // gera capa já com data de hoje e validade +5 dias

  document.getElementById('btn-gerar').addEventListener('click', atualizarCapa);

  // atualização em tempo real também (opcional, além do botão)
  ['in-cliente','in-representante','in-cidade','in-data','in-validade-dias']
    .forEach(id => document.getElementById(id).addEventListener('input', atualizarCapa));
});
